# EVERYTHING — Android project (v0.2.0)

A local-first personal library, collection manager and routine tracker for Android. Designed for a phone such as the Samsung Galaxy S24, with both light and dark themes.

## Included in this first build

- A browsable starter template library with 30+ categories (books, movies, TV, games, music, places, food, tech, clothing, collectibles, photography, anime/manga, podcasts, board games, fitness, recipes, art, watches, sneakers, tools, furniture, pets, events, projects, courses, apps/software, perfumes, coins/stamps, and custom collections).
- Custom collections.
- Manual item entry with notes, quantity, date, value and an optional attached picture.
- Routine creation with daily/weekly/monthly frequency, targets and manual logging.
- A basic statistics dashboard with collection, entry and log totals plus a category breakdown.
- Dark/light theme switch.
- JSON export and additive import of collections, entries, routines and complete routine-log history.
- Edit existing collection entries without deleting and recreating them.
- SQLite local database. No account, ads, analytics SDK, mandatory network access or subscription code.

## Build on Android Studio

1. Install Android Studio on a computer (Android Studio is required to build the native APK; this project is source code, not a precompiled APK).
2. Open this folder as an existing project.
3. Allow Android Studio to install the Android SDK / Gradle components it requests (compile SDK 35; JDK 17).
4. Wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location. Transfer it to the Galaxy S24 and install it.

## Important status / limitations

This is an initial functional foundation, not a finished commercial-grade release. It has not been compiled or device-tested in this environment because an Android SDK and Gradle installation are not available here. Review and test the generated APK before relying on it for important data.

Still planned: user-defined per-collection field schemas, routine history calendar and streak calculations, advanced graphs, cross-collection search, custom templates, map integration, widgets, and automated AI entry. Routine frequency is stored and displayed; the current dashboard shows today's progress, while weekly/monthly target calculations and due-date logic still need implementation. JSON import is additive: it appends backup contents and does not erase existing data. Importing the same backup more than once will create duplicates.

## Privacy

The app does not request internet permission. Data is stored in the app's private SQLite database. Export is user-initiated through Android's document picker. Attached images are referenced by persisted document URI; keep the source images available on the device. Uninstalling the app deletes its private database, so export backups regularly.

## Project details

- Application ID: `com.everything.app`
- Version: `0.1.0`
- Minimum Android: 8.0 (API 26)
- Target / compile SDK: 35
- Kotlin + Jetpack Compose + Material 3 + SQLite
