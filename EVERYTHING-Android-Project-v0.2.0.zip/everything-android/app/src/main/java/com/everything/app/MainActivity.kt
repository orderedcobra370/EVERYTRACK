package com.everything.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = EverythingDb(this)
        setContent { EverythingApp(db) }
    }
}

data class CollectionRow(val id: Long, val name: String, val emoji: String, val description: String, val template: String, val count: Int)
data class ItemRow(val id: Long, val collectionId: Long, val name: String, val notes: String, val quantity: Double, val value: Double, val date: String, val image: String)
data class RoutineRow(val id: Long, val name: String, val frequency: String, val unit: String, val target: Int, val count: Int, val lastDone: String)

data class Template(val name: String, val emoji: String, val description: String, val fields: String)

val templates = listOf(
    Template("Books", "📚", "Books you own, read or want to read", "Author, Genre, Status, Rating, Date finished"),
    Template("Movies", "🎬", "Films watched, collected or on your watchlist", "Director, Year, Genre, Rating, Watched"),
    Template("TV Shows", "📺", "Series, seasons and episodes", "Creator, Genre, Seasons, Status, Rating"),
    Template("Video Games", "🎮", "Your gaming library and completion progress", "Platform, Genre, Status, Hours played, Rating"),
    Template("Music", "🎵", "Albums, records, artists and releases", "Artist, Format, Genre, Release year, Rating"),
    Template("Places", "🌍", "Cities, countries, landmarks and destinations", "Country, Region, Visit date, Rating, Visited"),
    Template("Restaurants", "🍜", "Restaurants, cafés and food experiences", "Cuisine, Location, Visit date, Rating, Price"),
    Template("Food & Drinks", "☕", "Things you eat and drink, and how often", "Type, Brand, First tried, Favourite, Quantity"),
    Template("Technology", "📱", "Phones, computers, gadgets and accessories", "Brand, Model, Purchase date, Price, Condition"),
    Template("Clothing", "👕", "Clothes, shoes and accessories", "Brand, Size, Colour, Purchase date, Value"),
    Template("Collectibles", "💎", "Anything you collect", "Brand, Series, Condition, Purchase price, Value"),
    Template("Plants", "🪴", "Plants, care notes and growth", "Species, Location, Acquired, Watering interval"),
    Template("Photography", "📷", "Cameras, lenses, gear and photo projects", "Brand, Model, Purchase date, Value, Serial note"),
    Template("Anime & Manga", "🌸", "Series, volumes, characters and watchlists", "Creator, Genre, Status, Rating, Progress"),
    Template("Podcasts", "🎙️", "Shows, episodes and listening notes", "Host, Topic, Status, Rating, Episodes"),
    Template("Board Games", "🎲", "Tabletop games and expansions", "Players, Publisher, Playtime, Rating, Owned"),
    Template("Sports", "🏆", "Teams, events, matches and achievements", "Sport, Team, Date, Result, Notes"),
    Template("Fitness", "🏃", "Workouts, personal records and activities", "Activity, Duration, Distance, Date, Notes"),
    Template("Recipes", "🥘", "Recipes, ingredients and cooking notes", "Cuisine, Prep time, Difficulty, Rating"),
    Template("Art & Design", "🎨", "Artworks, artists, prints and inspiration", "Artist, Medium, Year, Value, Location"),
    Template("Watches", "⌚", "Watches, straps and accessories", "Brand, Model, Movement, Purchase date, Value"),
    Template("Sneakers", "👟", "Shoes, releases and rotation", "Brand, Model, Size, Colour, Purchase date"),
    Template("Tools", "🛠️", "Tools, equipment and workshop gear", "Brand, Model, Condition, Purchase date, Value"),
    Template("Furniture", "🛋️", "Furniture and things around your home", "Room, Brand, Purchase date, Value, Condition"),
    Template("Pets & Animals", "🐾", "Animals, care details and memories", "Species, Name, Birthday, Notes"),
    Template("Events", "🎟️", "Concerts, festivals, exhibitions and events", "Venue, Location, Date, Cost, Rating"),
    Template("Projects", "🧩", "Personal projects and things in progress", "Status, Start date, Deadline, Priority"),
    Template("Courses", "🎓", "Courses, lessons and things you learn", "Provider, Subject, Start date, Progress"),
    Template("Apps & Software", "💻", "Apps, tools, websites and software", "Platform, Developer, Category, Rating"),
    Template("Perfumes", "🧴", "Fragrances and scent collection", "Brand, Notes, Size, Purchase date, Rating"),
    Template("Coins & Stamps", "🪙", "Coins, stamps and historical pieces", "Country, Year, Condition, Value"),
    Template("Vehicles", "🚗", "Cars, bikes, public transport and more", "Make, Model, Year, Purchase date, Mileage"),
    Template("Games & Media", "🕹️", "Board games, apps, podcasts and media", "Type, Publisher, Release date, Rating, Status"),
    Template("Custom collection", "✨", "Build a collection for absolutely anything", "Notes, Quantity, Value, Date, Tags")
)

class EverythingDb(context: Context) : SQLiteOpenHelper(context, "everything.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE collections(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, emoji TEXT NOT NULL, description TEXT, template TEXT)")
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, collection_id INTEGER NOT NULL, name TEXT NOT NULL, notes TEXT, quantity REAL DEFAULT 1, value REAL DEFAULT 0, date TEXT, image TEXT, FOREIGN KEY(collection_id) REFERENCES collections(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE routines(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, frequency TEXT, unit TEXT, target INTEGER DEFAULT 1)")
        db.execSQL("CREATE TABLE routine_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, routine_id INTEGER NOT NULL, amount INTEGER DEFAULT 1, date TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCollection(name: String, emoji: String, description: String, template: String): Long {
        val v = ContentValues().apply { put("name", name); put("emoji", emoji); put("description", description); put("template", template) }
        return writableDatabase.insert("collections", null, v)
    }
    fun collections(): List<CollectionRow> {
        val out = mutableListOf<CollectionRow>(); val c = readableDatabase.rawQuery("SELECT c.id,c.name,c.emoji,IFNULL(c.description,''),IFNULL(c.template,''),(SELECT COUNT(*) FROM items i WHERE i.collection_id=c.id) FROM collections c ORDER BY c.name COLLATE NOCASE", null)
        c.use { while (it.moveToNext()) out.add(CollectionRow(it.getLong(0),it.getString(1),it.getString(2),it.getString(3),it.getString(4),it.getInt(5))) }; return out
    }
    fun addItem(cid: Long, name: String, notes: String, qty: Double, value: Double, date: String, image: String) {
        val v = ContentValues().apply { put("collection_id",cid); put("name",name); put("notes",notes); put("quantity",qty); put("value",value); put("date",date); put("image",image) }; writableDatabase.insert("items",null,v)
    }
    fun items(cid: Long): List<ItemRow> {
        val out=mutableListOf<ItemRow>(); val c=readableDatabase.rawQuery("SELECT id,collection_id,name,IFNULL(notes,''),quantity,value,IFNULL(date,''),IFNULL(image,'') FROM items WHERE collection_id=? ORDER BY name COLLATE NOCASE", arrayOf(cid.toString()))
        c.use { while(it.moveToNext()) out.add(ItemRow(it.getLong(0),it.getLong(1),it.getString(2),it.getString(3),it.getDouble(4),it.getDouble(5),it.getString(6),it.getString(7))) }; return out
    }
    fun item(id: Long): ItemRow? {
        val c = readableDatabase.rawQuery("SELECT id,collection_id,name,IFNULL(notes,''),quantity,value,IFNULL(date,''),IFNULL(image,'') FROM items WHERE id=?", arrayOf(id.toString()))
        c.use { if (!it.moveToFirst()) return null; return ItemRow(it.getLong(0),it.getLong(1),it.getString(2),it.getString(3),it.getDouble(4),it.getDouble(5),it.getString(6),it.getString(7)) }
    }
    fun updateItem(id: Long, name: String, notes: String, qty: Double, value: Double, date: String, image: String) {
        val v=ContentValues().apply { put("name",name);put("notes",notes);put("quantity",qty);put("value",value);put("date",date);put("image",image) }
        writableDatabase.update("items",v,"id=?",arrayOf(id.toString()))
    }
    fun deleteItem(id: Long) { writableDatabase.delete("items","id=?", arrayOf(id.toString())) }
    fun deleteCollection(id: Long) { writableDatabase.delete("items","collection_id=?",arrayOf(id.toString())); writableDatabase.delete("collections","id=?",arrayOf(id.toString())) }
    fun addRoutine(name: String, frequency: String, unit: String, target: Int) { val v=ContentValues().apply { put("name",name);put("frequency",frequency);put("unit",unit);put("target",target) }; writableDatabase.insert("routines",null,v) }
    fun routines(): List<RoutineRow> {
        val today=day(); val out=mutableListOf<RoutineRow>(); val c=readableDatabase.rawQuery("SELECT r.id,r.name,r.frequency,r.unit,r.target,IFNULL((SELECT SUM(amount) FROM routine_logs l WHERE l.routine_id=r.id AND l.date=?),0),IFNULL((SELECT MAX(date) FROM routine_logs l WHERE l.routine_id=r.id),'') FROM routines r ORDER BY r.name",arrayOf(today))
        c.use { while(it.moveToNext()) out.add(RoutineRow(it.getLong(0),it.getString(1),it.getString(2),it.getString(3),it.getInt(4),it.getInt(5),it.getString(6))) }; return out
    }
    fun logRoutine(id: Long, amount: Int=1) { val v=ContentValues().apply { put("routine_id",id);put("amount",amount);put("date",day()) }; writableDatabase.insert("routine_logs",null,v) }
    fun totals(): Triple<Int,Int,Int> {
        fun count(t:String)=readableDatabase.rawQuery("SELECT COUNT(*) FROM $t",null).use { if(it.moveToFirst()) it.getInt(0) else 0 }
        return Triple(count("collections"),count("items"),count("routine_logs"))
    }
    fun categoryStats(): List<Pair<String,Int>> { val o=mutableListOf<Pair<String,Int>>(); val c=readableDatabase.rawQuery("SELECT c.emoji||' '||c.name,COUNT(i.id) FROM collections c LEFT JOIN items i ON i.collection_id=c.id GROUP BY c.id ORDER BY COUNT(i.id) DESC LIMIT 8",null); c.use { while(it.moveToNext()) o.add(it.getString(0) to it.getInt(1)) }; return o }
    fun exportJson(): String {
        val root=JSONObject(); val cs=JSONArray(); collections().forEach { col -> val x=JSONObject().put("name",col.name).put("emoji",col.emoji).put("description",col.description).put("template",col.template); val arr=JSONArray(); items(col.id).forEach { arr.put(JSONObject().put("name",it.name).put("notes",it.notes).put("quantity",it.quantity).put("value",it.value).put("date",it.date).put("image",it.image)) }; x.put("items",arr); cs.put(x) }
        val rs=JSONArray(); val routineIds=readableDatabase.rawQuery("SELECT id,name,frequency,unit,target FROM routines ORDER BY id",null)
        routineIds.use { while(it.moveToNext()) { val id=it.getLong(0); val r=JSONObject().put("name",it.getString(1)).put("frequency",it.getString(2)).put("unit",it.getString(3)).put("target",it.getInt(4)); val logs=JSONArray(); val lc=readableDatabase.rawQuery("SELECT amount,date FROM routine_logs WHERE routine_id=? ORDER BY date,id",arrayOf(id.toString())); lc.use { while(it.moveToNext()) logs.put(JSONObject().put("amount",it.getInt(0)).put("date",it.getString(1))) }; r.put("logs",logs); rs.put(r) } }
        root.put("formatVersion",2).put("collections",cs).put("routines",rs).put("exportedAt",day()); return root.toString(2)
    }
    fun importJson(json: String): Pair<Int,Int> {
        val root=JSONObject(json); val cs=root.optJSONArray("collections") ?: JSONArray(); val rs=root.optJSONArray("routines") ?: JSONArray(); var importedItems=0; var importedCollections=0
        val d=writableDatabase; d.beginTransaction()
        try {
            for(i in 0 until cs.length()) { val c=cs.getJSONObject(i); val cv=ContentValues().apply { put("name",c.optString("name","Imported collection"));put("emoji",c.optString("emoji","✨"));put("description",c.optString("description",""));put("template",c.optString("template","Imported")) }; val cid=d.insert("collections",null,cv); if(cid>0) { importedCollections++; val arr=c.optJSONArray("items") ?: JSONArray(); for(j in 0 until arr.length()) { val x=arr.getJSONObject(j); val iv=ContentValues().apply { put("collection_id",cid);put("name",x.optString("name","Untitled"));put("notes",x.optString("notes",""));put("quantity",x.optDouble("quantity",1.0));put("value",x.optDouble("value",0.0));put("date",x.optString("date",""));put("image",x.optString("image","")) }; if(d.insert("items",null,iv)>0) importedItems++ } } }
            for(i in 0 until rs.length()) { val r=rs.getJSONObject(i); val rv=ContentValues().apply { put("name",r.optString("name","Imported routine"));put("frequency",r.optString("frequency","Daily"));put("unit",r.optString("unit","times"));put("target",r.optInt("target",1).coerceAtLeast(1)) }; val rid=d.insert("routines",null,rv); if(rid>0) { val logs=r.optJSONArray("logs") ?: JSONArray(); for(j in 0 until logs.length()) { val l=logs.getJSONObject(j); val lv=ContentValues().apply { put("routine_id",rid);put("amount",l.optInt("amount",1));put("date",l.optString("date",day())) }; d.insert("routine_logs",null,lv) } } }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return importedCollections to importedItems
    }
}
fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

private val ink = Color(0xFF171923)
private val muted = Color(0xFF777D8B)
private val accent = Color(0xFF6D63D9)

@Composable
fun EverythingApp(db: EverythingDb) {
    val context= LocalContext.current
    var dark by remember { mutableStateOf(context.getSharedPreferences("prefs",0).getBoolean("dark",true)) }
    var tab by remember { mutableStateOf("Library") }
    var selected by remember { mutableStateOf<Long?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var showNewCollection by remember { mutableStateOf(false) }
    var showNewRoutine by remember { mutableStateOf(false) }
    var showNewItem by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<ItemRow?>(null) }
    var importMessage by remember { mutableStateOf<String?>(null) }
    val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) runCatching { requireNotNull(context.contentResolver.openInputStream(uri)) { "Could not open the selected file" }.bufferedReader().use { db.importJson(it.readText()) } }.onSuccess { result -> importMessage="Imported ${result.first} collections and ${result.second} items.";refresh++ }.onFailure { importMessage="Import failed: ${it.message ?: "Invalid backup file"}" } }
    var chosenTemplate by remember { mutableStateOf<Template?>(null) }
    val exportLauncher= rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if(uri!=null) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray()) } } }
    val scheme= if(dark) darkColorScheme(primary=Color(0xFFAAA2FF),secondary=Color(0xFF85CBB0),background=Color(0xFF11131A),surface=Color(0xFF1B1E28),onBackground=Color(0xFFF4F3FA),onSurface=Color(0xFFF4F3FA)) else lightColorScheme(primary=accent,secondary=Color(0xFF367C67),background=Color(0xFFF5F5F8),surface=Color.White,onBackground=ink,onSurface=ink)
    MaterialTheme(colorScheme=scheme) {
        val cols= remember(refresh) { db.collections() }
        val routines= remember(refresh) { db.routines() }
        val totals= remember(refresh) { db.totals() }
        Scaffold(containerColor=MaterialTheme.colorScheme.background, bottomBar={
            NavigationBar(containerColor=MaterialTheme.colorScheme.surface) {
                listOf("Library","Track","Stats","Settings").forEach { t ->
                    val icon=when(t){"Library"->Icons.Default.CollectionsBookmark;"Track"->Icons.Default.TaskAlt;"Stats"->Icons.Default.AutoGraph;else->Icons.Default.Settings}
                    NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(icon,null)},label={Text(t)})
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
                Spacer(Modifier.height(16.dp))
                if(selected!=null) {
                    val col=cols.firstOrNull { it.id==selected }
                    if(col!=null) CollectionDetail(col,db,refresh,{showNewItem=true},{selected=null;refresh++},{refresh++},{ item -> editingItem=item })
                    else selected=null
                } else when(tab) {
                    "Library" -> LibraryScreen(cols,{ selected=it },{showNewCollection=true})
                    "Track" -> TrackScreen(routines,{showNewRoutine=true},{ id -> db.logRoutine(id);refresh++ })
                    "Stats" -> StatsScreen(totals,db.categoryStats())
                    else -> SettingsScreen(dark,{ dark=it;context.getSharedPreferences("prefs",0).edit().putBoolean("dark",it).apply() },{exportLauncher.launch("everything-backup-${day()}.json")},{importLauncher.launch(arrayOf("application/json","text/*"))})
                }
            }
        }
        if(showNewCollection) CollectionDialog(onDismiss={showNewCollection=false},onTemplate={chosenTemplate=it;showNewCollection=false},onCustom={name,emoji,desc -> db.addCollection(name,emoji,desc,"Custom");showNewCollection=false;refresh++})
        if(chosenTemplate!=null) TemplateDialog(chosenTemplate!!,{chosenTemplate=null},{ name,desc -> val t=chosenTemplate!!;db.addCollection(name,t.emoji,desc,t.name);chosenTemplate=null;refresh++ })
        if(showNewRoutine) RoutineDialog({showNewRoutine=false},{name,freq,unit,target->db.addRoutine(name,freq,unit,target);showNewRoutine=false;refresh++})
        if(showNewItem && selected!=null) ItemDialog(onDismiss={showNewItem=false},onSave={name,notes,qty,value,date,image->db.addItem(selected!!,name,notes,qty,value,date,image);showNewItem=false;refresh++})
        if(editingItem!=null) ItemDialog(initial=editingItem,onDismiss={editingItem=null},onSave={name,notes,qty,value,date,image->db.updateItem(editingItem!!.id,name,notes,qty,value,date,image);editingItem=null;refresh++})
        if(importMessage!=null) AlertDialog(onDismissRequest={importMessage=null},title={Text("Backup import")},text={Text(importMessage!!)},confirmButton={TextButton(onClick={importMessage=null}){Text("OK")}})
    }
}

@Composable fun Header(title:String, subtitle:String?=null, action:(()->Unit)?=null, actionText:String="+") {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) { Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold,letterSpacing=(-0.7).sp); if(subtitle!=null) Text(subtitle,color=muted,fontSize=13.sp) }
        if(action!=null) FilledTonalIconButton(onClick=action) { Icon(Icons.Default.Add,actionText) }
    }
}
@Composable fun LibraryScreen(cols:List<CollectionRow>,open:(Long)->Unit,add:()->Unit) {
    var query by remember { mutableStateOf("") }
    Header("Your universe","A home for everything you keep track of",add)
    Spacer(Modifier.height(18.dp))
    OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search your library")},leadingIcon={Icon(Icons.Default.Search,null)},shape=RoundedCornerShape(16.dp))
    Spacer(Modifier.height(16.dp))
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) { Text("MY COLLECTIONS",fontSize=11.sp,fontWeight=FontWeight.Bold,color=muted,letterSpacing=1.2.sp); Text("${cols.size} collections",fontSize=12.sp,color=muted) }
    Spacer(Modifier.height(8.dp))
    if(cols.isEmpty()) {
        Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("✨",fontSize=48.sp); Spacer(Modifier.height(12.dp)); Text("Your library starts here",fontWeight=FontWeight.Bold,fontSize=19.sp); Text("Browse the template library and add your first collection.",color=muted,fontSize=13.sp); Spacer(Modifier.height(16.dp)); Button(onClick=add) { Icon(Icons.Default.Add,null); Text("  Browse templates") } } }
    } else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=20.dp),modifier=Modifier.weight(1f)) {
        val filtered=cols.filter { it.name.contains(query,true)||it.description.contains(query,true) }
        items(filtered) { c -> Card(onClick={open(c.id)},shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(if(MaterialTheme.colorScheme.background==Color(0xFF11131A)) Color(0xFF2A2D3B) else Color(0xFFF0EFFB)),contentAlignment=Alignment.Center) { Text(c.emoji,fontSize=26.sp) }; Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(c.name,fontWeight=FontWeight.SemiBold,fontSize=16.sp); Text(c.description.ifBlank { c.template },fontSize=12.sp,color=muted,maxLines=1) }; Column(horizontalAlignment=Alignment.End) { Text(c.count.toString(),fontWeight=FontWeight.Bold,fontSize=18.sp); Text("items",fontSize=10.sp,color=muted) } } } }
    }
    if(cols.isNotEmpty()) Button(onClick=add,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)) { Icon(Icons.Default.Add,null); Text("  Add to library") }
}

@Composable fun CollectionDetail(col:CollectionRow,db:EverythingDb,revision:Int,add:()->Unit,back:()->Unit,changed:()->Unit,edit:(ItemRow)->Unit) {
    var items by remember(col.id,revision) { mutableStateOf(db.items(col.id)) }
    Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=back) { Icon(Icons.Default.ArrowBack,null) }; Column { Text("${col.emoji}  ${col.name}",fontSize=23.sp,fontWeight=FontWeight.Bold); Text("${items.size} entries · ${col.description}",fontSize=12.sp,color=muted,maxLines=1) } }
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) { Text("YOUR ITEMS",fontSize=11.sp,fontWeight=FontWeight.Bold,color=muted,letterSpacing=1.sp); FilledTonalButton(onClick=add) { Icon(Icons.Default.Add,null);Text("Add item") } }
    Spacer(Modifier.height(8.dp))
    if(items.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("📦",fontSize=44.sp); Text("Nothing here yet",fontWeight=FontWeight.Bold); Text("Add your first entry to this collection.",color=muted,fontSize=13.sp) } }
    else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.weight(1f),contentPadding=PaddingValues(bottom=16.dp)) { items(items) { item -> Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) { if(item.image.isNotBlank()) AsyncImage(model=item.image,contentDescription=item.name,modifier=Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))) else Text("▫️",fontSize=23.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(item.name,fontWeight=FontWeight.SemiBold); if(item.notes.isNotBlank()) Text(item.notes,color=muted,fontSize=12.sp,maxLines=2); Text("Qty ${item.quantity.toInt()}  ·  ${item.date}",color=muted,fontSize=11.sp) }; if(item.value>0) Text("${"%.2f".format(item.value)}",fontWeight=FontWeight.SemiBold); IconButton(onClick={edit(item)}) { Icon(Icons.Default.Edit,null,tint=muted) }; IconButton(onClick={db.deleteItem(item.id);items=db.items(col.id);changed()}) { Icon(Icons.Default.Delete,null,tint=muted) } } } } }
}

@Composable fun TrackScreen(routines:List<RoutineRow>,add:()->Unit,log:(Long)->Unit) {
    Header("Your routines","Small actions. Lifetime history.",add)
    Spacer(Modifier.height(18.dp))
    if(routines.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("🔁",fontSize=44.sp); Text("Build your rhythm",fontWeight=FontWeight.Bold,fontSize=19.sp); Text("Track anything you repeat: reading, workouts,",color=muted,fontSize=13.sp); Text("coffee, photography, walks and more.",color=muted,fontSize=13.sp); Spacer(Modifier.height(14.dp)); Button(onClick=add) { Icon(Icons.Default.Add,null);Text("  Create a routine") } } }
    else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)) { items(routines) { r -> Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(r.name,fontWeight=FontWeight.SemiBold,fontSize=16.sp); Text("${r.frequency} · Target ${r.target} ${r.unit}",fontSize=12.sp,color=muted) }; FilledTonalButton(onClick={log(r.id)}) { Icon(Icons.Default.CheckCircle,null); Text("  Log") } }; Spacer(Modifier.height(10.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Text("${r.count} / ${r.target} ${r.unit} today",fontSize=12.sp,color=muted); Spacer(Modifier.weight(1f)); Text(if(r.count>=r.target) "Completed" else "In progress",fontSize=11.sp,color=if(r.count>=r.target) Color(0xFF31956F) else muted) }; LinearProgressIndicator(progress={ (r.count.toFloat()/r.target.coerceAtLeast(1)).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth().padding(top=7.dp)) } } } }
}

@Composable fun StatsScreen(t:Triple<Int,Int,Int>,stats:List<Pair<String,Int>>) {
    Header("Your statistics","Everything adds up over time")
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { StatCard("Collections",t.first.toString(),"🗂️",Modifier.weight(1f));StatCard("Entries",t.second.toString(),"📦",Modifier.weight(1f));StatCard("Logs",t.third.toString(),"🔁",Modifier.weight(1f)) }
    Spacer(Modifier.height(22.dp)); Text("COLLECTION BREAKDOWN",fontSize=11.sp,fontWeight=FontWeight.Bold,color=muted,letterSpacing=1.sp); Spacer(Modifier.height(10.dp))
    if(stats.isEmpty()) Text("Your collection statistics will appear here as you add things.",color=muted,fontSize=13.sp)
    stats.forEach { (name,count) -> Column(Modifier.fillMaxWidth().padding(vertical=7.dp)) { Row { Text(name,Modifier.weight(1f),fontWeight=FontWeight.Medium);Text("$count items",color=muted,fontSize=12.sp) }; LinearProgressIndicator(progress={count.toFloat()/stats.maxOf { it.second }.coerceAtLeast(1)},modifier=Modifier.fillMaxWidth().padding(top=6.dp)) } }
    Spacer(Modifier.height(18.dp)); Text("More insights are planned: lifetime value, most-used categories, monthly activity, personal records and custom charts.",fontSize=12.sp,color=muted)
}
@Composable fun StatCard(label:String,value:String,emoji:String,modifier:Modifier) { Card(modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(13.dp)) { Text(emoji,fontSize=20.sp); Text(value,fontSize=25.sp,fontWeight=FontWeight.Bold); Text(label,fontSize=11.sp,color=muted) } } }

@Composable fun SettingsScreen(dark:Boolean,onDark:(Boolean)->Unit,export:()->Unit,importBackup:()->Unit) {
    Header("Settings","Your data stays yours")
    Spacer(Modifier.height(16.dp))
    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(dark) Icons.Default.DarkMode else Icons.Default.LightMode,null); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Appearance",fontWeight=FontWeight.SemiBold); Text("Switch between dark and light themes",fontSize=12.sp,color=muted) }; Switch(dark,onDark) }; Divider(Modifier.padding(vertical=12.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Bookmark,null);Spacer(Modifier.width(12.dp));Column { Text("Local-first storage",fontWeight=FontWeight.SemiBold);Text("Your database lives on this device.",fontSize=12.sp,color=muted) } }; Divider(Modifier.padding(vertical=12.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Explore,null);Spacer(Modifier.width(12.dp));Column { Text("No account · No ads · No subscription",fontWeight=FontWeight.SemiBold);Text("No analytics or mandatory network connection.",fontSize=12.sp,color=muted) } } } }
    Spacer(Modifier.height(14.dp)); OutlinedButton(onClick=export,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) { Text("Export all data as JSON") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick=importBackup,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) { Text("Import / restore JSON backup") }; Spacer(Modifier.height(8.dp)); Text("Import adds the backup contents to your existing library; it does not erase current data.",fontSize=11.sp,color=muted); Spacer(Modifier.height(8.dp)); Text("EVERYTHING · Version 0.2.0\nAn independent personal library.",fontSize=11.sp,color=muted)
}

@Composable fun CollectionDialog(onDismiss:()->Unit,onTemplate:(Template)->Unit,onCustom:(String,String,String)->Unit) {
    var query by remember { mutableStateOf("") }; var custom by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var emoji by remember { mutableStateOf("✨") }; var desc by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(custom) "Create custom collection" else "Browse the library")},text={ Column(Modifier.heightIn(max=520.dp)) {
        if(custom) { OutlinedTextField(name,{name=it},label={Text("Collection name")},singleLine=true);OutlinedTextField(emoji,{emoji=it},label={Text("Icon or emoji")},singleLine=true);OutlinedTextField(desc,{desc=it},label={Text("Description")}); TextButton(onClick={custom=false}) { Text("← Browse templates") } }
        else { OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search categories")}); Spacer(Modifier.height(8.dp)); LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) { items(templates.filter { it.name.contains(query,true)||it.description.contains(query,true) }) { t -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTemplate(t) }.padding(10.dp),verticalAlignment=Alignment.CenterVertically) { Text(t.emoji,fontSize=25.sp);Spacer(Modifier.width(12.dp));Column { Text(t.name,fontWeight=FontWeight.SemiBold);Text(t.description,fontSize=11.sp,color=muted,maxLines=1) } } } }; TextButton(onClick={custom=true}) { Text("＋ Create completely custom") } }
    }},confirmButton={ if(custom) TextButton(onClick={if(name.isNotBlank()) onCustom(name,emoji.ifBlank{"✨"},desc)}) { Text("Create") } else TextButton(onClick=onDismiss) { Text("Close") } },dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable fun TemplateDialog(template:Template,onDismiss:()->Unit,onCreate:(String,String)->Unit) {
    var name by remember { mutableStateOf(template.name) }; var desc by remember { mutableStateOf(template.description) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Add ${template.emoji} ${template.name}")},text={Column { Text("Suggested fields: ${template.fields}",fontSize=12.sp,color=muted);Spacer(Modifier.height(10.dp));OutlinedTextField(name,{name=it},label={Text("Collection name")});OutlinedTextField(desc,{desc=it},label={Text("Description")}) }},confirmButton={TextButton(onClick={if(name.isNotBlank()) onCreate(name,desc)}){Text("Add collection")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable fun RoutineDialog(onDismiss:()->Unit,onCreate:(String,String,String,Int)->Unit) {
    var name by remember { mutableStateOf("") };var frequency by remember { mutableStateOf("Daily") };var unit by remember { mutableStateOf("times") };var target by remember { mutableStateOf("1") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Create a routine")},text={Column { OutlinedTextField(name,{name=it},label={Text("What do you want to track?")},singleLine=true);Spacer(Modifier.height(8.dp));Text("Frequency",fontSize=12.sp,color=muted);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("Daily","Weekly","Monthly").forEach { FilterChip(selected=frequency==it,onClick={frequency=it},label={Text(it)}) } };OutlinedTextField(target,{target=it.filter(Char::isDigit)},label={Text("Target per period")},singleLine=true);OutlinedTextField(unit,{unit=it},label={Text("Unit (times, pages, km…)")},singleLine=true) }},confirmButton={TextButton(onClick={if(name.isNotBlank()) onCreate(name,frequency,unit,target.toIntOrNull()?.coerceAtLeast(1)?:1)}){Text("Create")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable fun ItemDialog(initial:ItemRow?=null,onDismiss:()->Unit,onSave:(String,String,Double,Double,String,String)->Unit) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name ?: "") };var notes by remember(initial?.id) { mutableStateOf(initial?.notes ?: "") };var qty by remember(initial?.id) { mutableStateOf(initial?.quantity?.toString() ?: "1") };var value by remember(initial?.id) { mutableStateOf(initial?.value?.takeIf { it>0 }?.toString() ?: "") };var date by remember(initial?.id) { mutableStateOf(initial?.date?.ifBlank { day() } ?: day()) };var image by remember(initial?.id) { mutableStateOf(initial?.image ?: "") }
    val context= LocalContext.current
    val picker= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri:Uri? -> if(uri!=null) { runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }; image=uri.toString() } }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(initial==null) "Add an entry" else "Edit entry")},text={Column(Modifier.heightIn(max=520.dp)) { OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true);OutlinedTextField(notes,{notes=it},label={Text("Description / notes")},minLines=2);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(qty,{qty=it.filter { c->c.isDigit()||c=='.' }},modifier=Modifier.weight(1f),label={Text("Quantity")},singleLine=true);OutlinedTextField(value,{value=it.filter { c->c.isDigit()||c=='.' }},modifier=Modifier.weight(1f),label={Text("Value (€)")},singleLine=true) };OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Image,null);Text(if(image.isBlank()) "  Attach picture" else "  Picture selected") } }},confirmButton={TextButton(onClick={if(name.isNotBlank()) onSave(name,notes,qty.toDoubleOrNull()?:1.0,value.toDoubleOrNull()?:0.0,date,image)}){Text(if(initial==null) "Save entry" else "Save changes")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
